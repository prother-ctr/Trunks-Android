# Trunks Android 1.0

Prototipo Android nativo Kotlin + Jetpack Compose.

Funzioni: Home, avatar locale, Chat dimostrativa, NO RISPOSTA, Materie e Progressi.

Per compilare: aprire il progetto in Android Studio e generare l'APK debug.
