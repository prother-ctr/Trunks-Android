package com.trunks.study

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080A10)
private val Card = Color(0xFF111522)
private val Accent = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF57D6FF)
private val Muted = Color(0xFF9BA4B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TrunksApp() }
    }
}

@Composable
fun TrunksApp() {
    var tab by remember { mutableStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Card, primary = Accent, secondary = Cyan
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0D101A)) {
                    listOf("Home" to Icons.Default.Home, "Trunks" to Icons.Default.Chat,
                        "Studio" to Icons.Default.MenuBook, "Progressi" to Icons.Default.Insights)
                        .forEachIndexed { i, pair ->
                            NavigationBarItem(
                                selected = tab == i, onClick = { tab = i },
                                icon = { Icon(pair.second, null) },
                                label = { Text(pair.first, fontSize = 11.sp) })
                        }
                }
            }
        ) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                when(tab) {
                    0 -> HomeScreen { tab = 1 }
                    1 -> ChatScreen()
                    2 -> StudioScreen()
                    else -> ProgressScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen(openChat: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 24.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("TRUNKS", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("Pronto a studiare?", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Non ti darò la risposta. Ti aiuterò a trovarla.", color = Muted)
        }
        item {
            Card(Modifier.fillMaxWidth().height(260.dp), RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF10152A))) {
                Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.trunks_avatar), "Avatar Trunks",
                        Modifier.width(170.dp).fillMaxHeight())
                    Column(Modifier.padding(18.dp).weight(1f)) {
                        Text("EHI.", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("Da dove\npartiamo?", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(18.dp))
                        Button(onClick = openChat, shape = RoundedCornerShape(16.dp)) {
                            Icon(Icons.Default.Chat, null); Spacer(Modifier.width(8.dp)); Text("Parla con me")
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Card)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, null, tint = Accent)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("NO RISPOSTA", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Modalità attiva", color = Muted, fontSize = 13.sp)
                    }
                    Switch(checked = true, onCheckedChange = {})
                }
            }
        }
        item {
            Card(RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
                Column(Modifier.padding(18.dp)) {
                    Text("OBIETTIVO DI OGGI", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Equazioni di primo grado", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Matematica · 3 esercizi", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(progress = { .72f }, Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
fun ChatScreen() {
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf(
        "Ciao! Sono Trunks. Dimmi cosa stai cercando di capire.",
        "NO RISPOSTA è attiva: ti guiderò, ma il passaggio finale lo fai tu."
    )) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("TRUNKS", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("Tutor", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages.size) { i ->
                Card(RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
                    Text(messages[i], Modifier.padding(16.dp), color = Color.White)
                }
            }
        }
        Row(verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(value = input, onValueChange = { input = it },
                Modifier.weight(1f), placeholder = { Text("Scrivi a Trunks…") }, shape = RoundedCornerShape(18.dp))
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = {
                if (input.isNotBlank()) {
                    messages = messages + input + "Ok. Prima domanda: qual è la parte dell'esercizio che sai già impostare?"
                    input = ""
                }
            }, Modifier.size(56.dp).clip(CircleShape).background(Accent)) {
                Icon(Icons.Default.Send, null, tint = Color.White)
            }
        }
    }
}

@Composable
fun StudioScreen() {
    val subjects = listOf("Matematica", "Italiano", "Inglese", "Scienze", "Storia", "Fisica")
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("STUDIO", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold); Text("Le tue materie", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        items(subjects.size) { i ->
            Card(RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MenuBook, null, tint = Cyan); Spacer(Modifier.width(14.dp))
                    Text(subjects[i], Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.SemiBold)
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
fun ProgressScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("PROGRESSI", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("Stai crescendo.", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Card(RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
            Column(Modifier.padding(20.dp)) {
                Text("Livello di studio", color = Muted)
                Text("72%", color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { .72f }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("12 argomenti · 37 esercizi · 8 errori corretti", color = Muted, fontSize = 13.sp)
            }
        }
    }
}
